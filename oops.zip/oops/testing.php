<?php
$n=5;
do{
	echo "mahender";
}
while($n < 3);


for($i=1;$i<=10;$i++){

	echo $i."<br>";
	$i++;
}

$num=1;
echo $num+=3;
?>