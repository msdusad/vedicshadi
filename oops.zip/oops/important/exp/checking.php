<?php
include('incudeit.php');
echo Save::abc();
?>
<form method="post" action="">
<input type="text" name="user">
<input type="submit" name="submit" value="M">
</form>