<?php
$number=5;
$fact=1;
for($i=1;$i<=$number;$i++){
$fact=$fact*$i;
}
echo $fact;
