<?php
$a="<h1>mahender</h1><p>singh<b>dusad</b></p>";

echo strip_tags($a);
