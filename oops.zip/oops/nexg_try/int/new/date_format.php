<?php
$date="11-02-2016";
//$date=date('y-m-d',strtotime($date));
echo strrev($date);
