<?php
$var=array(true=>'1',b=>'Mah');	
var_dump($var);
?>
