<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js">
</script>
<script type="text/javascript">
$(document).ready(function(){
$("#xz" ).live( "click", function(){
	  $("p").slideToggle();
} );
});
</script>
<p>Mahender Sidsd</p>
<button id="xz">click</button>