<?php
$a="aab";
 $b=str_rot13($a); // CUC 4.3.0
echo $b."<br>";

$c=str_rot13($b);
echo $c;
?>