<?php
$a="msdusad@gmail.com";
print_r(str_split($a));
print_r(str_split($a,5));