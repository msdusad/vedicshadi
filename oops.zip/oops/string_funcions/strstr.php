<?php

$a="msdusad@gmail.com";
echo strstr($a,'@',false)."<br>";
echo strstr($a,'@',true);