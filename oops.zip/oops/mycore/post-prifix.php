<?php
$first=100;
$second=20;
$third=10;
$four=2;
echo $first++."<br>";
echo $second--."<br>";
echo ++$third."<br>";
echo --$four."<br>"	;

?>