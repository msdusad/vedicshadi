<?php

$num=10;
for($num;$num<20;$num++){

	echo $num."<br>";
}