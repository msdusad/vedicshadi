<?php

mysql_connect('localhost','root','','dfd') or die('Can not connect');

echo "Connected";
/*

die() and exit() are same in use 
the script ends if error findout before die and exit()
*/
?>