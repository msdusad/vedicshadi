<?php
$first=100;
$second=20;
$third=10;
$four=2;
$res=$first-$second+$third/$four;
echo $res;

?>