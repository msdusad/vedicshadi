<?php
$str="Mahender Singh Dusad";
$str_new=substr_replace($str,'LOL', 9,5);
echo $str_new;


?>