<?
echo phpinfo();	
?>
