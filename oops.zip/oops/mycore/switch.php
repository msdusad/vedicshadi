<?php
$num='maahi';
switch ($num) {
	case '1':
		echo "M";
		break;

		case '2':
		echo "MA";
		break;

		case '3':
		echo "MAH";
		break;

		case '4':
		echo "MAHE";
		break;

		case 'maahi':
		echo "MAHEN";
		break;
	
	default:
		echo "Maahi Dusad";
		break;
}




?>