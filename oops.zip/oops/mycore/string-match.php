<?php
$string="Find out in this";
//$find=preg_match('/out in/',$string);
if(preg_match('/out in/' ,$string)){
echo "Find Success";

}
else{

echo "Not found";
}

?>