<?
$name="Mahender Singh";
echo strtolower($name)."<br>";
echo strtoupper($name);
?>
