<?php

class Testing {

public $total_count=12;

public  function sum($ar1,$ar2){
//$this->total_count=23;
return $this->total_count;
}
public function substract($ar1,$ar2){
 return $this->total=$ar1-$ar2;
 
}

}
echo Testing::sum(10,11);



?>